from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from .models import Note
from .forms import NoteForm


def index(request):
    notes = Note.objects.all()
    form = NoteForm()
    return render(request, 'notes/index.html', {'notes': notes, 'form': form})


def create_note(request):
    if request.method == 'POST':
        form = NoteForm(request.POST)
        if form.is_valid():
            note = form.save()
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({
                    'id': note.id,
                    'title': note.title,
                    'content': note.content,
                    'color': note.color,
                })
            return redirect('index')
    return JsonResponse({'error': 'Invalid form'}, status=400)


def edit_note(request, note_id):
    note = get_object_or_404(Note, id=note_id)
    if request.method == 'POST':
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            note = form.save()
            return JsonResponse({
                'id': note.id,
                'title': note.title,
                'content': note.content,
                'color': note.color
            })
    return JsonResponse({'error': 'Invalid data'}, status=400)


def delete_note(request, note_id):
    note = get_object_or_404(Note, id=note_id)
    note.delete()
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'status': 'deleted'})
    return redirect('index')
