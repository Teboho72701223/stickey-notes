from django.test import TestCase, Client
from django.urls import reverse
from ..models import Note


class NoteViewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.note = Note.objects.create(
            title="Test Note",
            content="This is a test note.",
            color="yellow",
            pinned=False
        )

    # Index Note(Note)
    def test_index_view_status_code_and_template(self):
        response = self.client.get(reverse('index'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/index.html')
        self.assertIn('notes', response.context)
        self.assertIn('form', response.context)

    # Create Note(Test)
    def test_create_note_view_post_request(self):
        data = {'title': 'New Note', 'content': 'New content', 'color': 'blue',
                'pinned': False}
        response = self.client.post(reverse('create_note'), data)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Note.objects.filter(title='New Note').exists())

    def test_create_note_view_invalid_post(self):
        data = {'title': '', 'content': '', 'color': 'blue'}
        response = self.client.post(reverse('create_note'), data)
        self.assertEqual(response.status_code, 400)
        self.assertJSONEqual(response.content, {'error': 'Invalid form'})

    # Edit Note(Test)
    def test_edit_note_view_post_request(self):
        data = {
            'title': 'Updated Note', 'content': 'Updated content', 'color':
            'red', 'pinned': True}
        response = self.client.post(reverse(
            'edit_note', args=[self.note.id]), data
            )
        self.assertEqual(response.status_code, 200)
        updated_note = Note.objects.get(id=self.note.id)
        self.assertEqual(updated_note.title, 'Updated Note')
        self.assertEqual(updated_note.content, 'Updated content')

    def test_edit_note_view_invalid_post(self):
        data = {'title': '', 'content': ''}
        response = self.client.post(reverse(
            'edit_note', args=[self.note.id]), data
                    )
        self.assertEqual(response.status_code, 400)
        self.assertJSONEqual(response.content, {'error': 'Invalid data'})

    def test_edit_note_view_invalid_id(self):
        data = {'title': 'X', 'content': 'Y'}
        response = self.client.post(reverse('edit_note', args=[9999]), data)
        self.assertEqual(response.status_code, 404)

    # Delete Note(Test)
    def test_delete_note_view(self):
        response = self.client.post(reverse(
            'delete_note', args=[self.note.id]
            ))
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Note.objects.filter(id=self.note.id).exists())

    def test_delete_note_view_invalid_id(self):
        response = self.client.post(reverse('delete_note', args=[9999]))
        self.assertEqual(response.status_code, 404)
