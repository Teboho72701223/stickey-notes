from django import forms
from .models import Note


class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ['title', 'content', 'color', 'pinned']
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'Title'}),
            'content': forms.Textarea(attrs={'placeholder': 'Your note here...', 'rows': 3}),
            'color': forms.TextInput(attrs={'type': 'color'}),
            'pinned': forms.CheckboxInput(),
        }
